from .main import Hulaquan

__all__ = ["Hulaquan"]
